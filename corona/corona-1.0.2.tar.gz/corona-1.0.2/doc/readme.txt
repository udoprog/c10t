Corona Readme
2002.02.21
Chad Austin (aegis@aegisknight.org)


Corona is a convenient, high-level image loading and saving API.  It
lets you add support for loading and saving images in your application
very easily.
